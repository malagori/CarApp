<header class="mainHeader">
<img src="http://www.nisha.se/carapp/images/Header.png" />
<p>

</p>

<nav>
<ul>
<li class="active"><a href="http://localhost/carapp">Hem</a></li>
</ul>

<form action="search.php" method="get" enctype="multipart/form-data">
<input type="text" name="value" placeholder="Seach in this site" size="30">
<input type="submit" name="search" value="search">
</form>

</nav>

</header>