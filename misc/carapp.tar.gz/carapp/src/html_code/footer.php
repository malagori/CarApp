<footer class="mainFooter">
<p>Copyright &copy;  <a href="http://zia-ullah-khan.blogspot.se/" title="Zia Personal Site">Zia Khan</a></p>
</footer>