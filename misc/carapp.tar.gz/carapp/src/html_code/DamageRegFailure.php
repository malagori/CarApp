<?php
/**
 * Author: Mehmood Alam Khan
 * Email: malagori@kth.se
 * Dated: 6 April 2014
 */


$msg = $_GET['msg'];
echo "$msg";

?>