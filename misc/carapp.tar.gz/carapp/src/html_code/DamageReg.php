<html>
<head>
<title>Car Repairing</title>
<meta charset="utf-8">
<link rel="stylesheet" type="text/css" href="../css_code/style.css">
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
</head>

<body class="body">

<div><?php include("header.php"); ?></div>
<div><?php include("damage.php"); ?></div>
<div> <?php include("includes/sidebar.php"); ?> </div>
<div><?php include("footer.php"); ?></div>


</body>
</html>