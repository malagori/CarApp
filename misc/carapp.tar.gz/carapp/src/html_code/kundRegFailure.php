<?php
/**
 * Author: Mehmood Alam Khan
 * Email: malagori@kth.se
 */


$msg = $_GET['msg'];
echo "$msg";

?>