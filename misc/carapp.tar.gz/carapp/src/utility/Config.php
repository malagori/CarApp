<?php
/**
 * Author: Mehmood Alam Khan
 * Email: malagori@kth.se
 * Dated: 5 April 2014
 */

require_once('MyConstants.php');
error_reporting(E_ERROR);


//Various application invitation  constants
$url = MyConstants::ABS_URL;
$about_url=MyConstants::ABOUT_URL;

$appname =MyConstants::APP_NAME ;

?>